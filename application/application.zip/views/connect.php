<?php 
//connect.php;
$con = mysqli_connect("localhost", "root", "", "cigenerator");
?>
